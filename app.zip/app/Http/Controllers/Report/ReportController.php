<?php

namespace App\Http\Controllers\Report;
use Barryvdh\DomPDF\Facade\Pdf; 
use App\Http\Controllers\Controller;
use App\Models\Report;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;


class ReportController extends Controller
{
    public function index()
    {
        $reports = Report::with('user')->orderBy('id', 'desc')->get();

        return Inertia::render('Reports/Index', [
            'reports' => $reports,
        ]);
    }

    public function create()
    {
        return Inertia::render('Reports/Create');
    }

    public function store(Request $request)
    {
        $messages = [
            'required' => ':attribute tidak boleh kosong !',
        ];
        $attributes = [
            'name'        => 'nama',
            'positions'   => 'posisi',
            'room'        => 'ruangan',
            'facility'    => 'fasilitas',
            'category'    => 'kategori',
            'description' => 'deskripsi',
            'image'       => 'gambar',
        ];

        $request->validate([
            'name'        => 'required|string|max:255',
            'positions'   => 'required|string|max:255',
            'room'        => 'required|string|max:255',
            'facility'    => 'required|string|max:255',
            'category'    => 'required|string|in:IT,IPSRS',
            'description' => 'required|string',
            'image'       => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ], $messages, $attributes);

        $lastReport = Report::latest('id')->first();
        $nextNumber = $lastReport ? ((int) str_replace('NP', '', $lastReport->custom_id)) + 1 : 1;
        $customId = 'NP' . $nextNumber;

        $imagePath = null;
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('reports', 'public');
        }

        $report = Report::create([
            'custom_id'   => $customId,
            'name'        => $request->name,
            'positions'   => $request->positions,
            'room'        => $request->room,
            'facility'    => $request->facility,
            'category'    => $request->category,
            'description' => $request->description,
            'status'      => 'Sedang diajukan',
            'note'        => '',
            'created_by'  => auth()->id(),
            'image'       => $imagePath,
        ]);

        // Simpan riwayat awal diajukan
        $report->histories()->create([
            'user_id' => auth()->id(),
            'status'  => 'Sedang diajukan',
            'note'    => $request->description,
            'image'   => $imagePath,
        ]);

        event(new \App\Events\ReportCreated($report));

        return redirect()->route('reports.index')
            ->with('success', 'Report created successfully.');
    }

    public function show(Report $report)
    {
        $report->load(['creator', 'updater', 'histories.user']); 
    
        return Inertia::render('Reports/Show', [
            'report' => $report,
        ]);
    }

    public function response($id)
    {
        $report = \App\Models\Report::with(['creator', 'updater', 'histories.user'])->findOrFail($id);

        return inertia('Reports/Response', [
            'report' => $report,
            'auth' => [
                'user' => auth()->user(),
            ],
        ]);
    }

    
    public function edit(Report $report)
    {
        return Inertia::render('Reports/Edit', [
            'report' => $report,
        ]);
    }

    public function update(Request $request, Report $report)
    {
        $messages = [
            'required' => ':attribute tidak boleh kosong !',
        ];

        $attributes = [
            'name'          => 'nama',
            'positions'     => 'posisi',
            'room'          => 'ruangan',
            'facility'      => 'fasilitas',
            'category'      => 'kategori',
            'description'   => 'deskripsi',
            'status'        => 'status',
            'note'          => 'catatan',
            'process_image' => 'foto selesai',
            'image'         => 'foto awal',
        ];

        // 🔹 Buat aturan dasar
        $rules = [
            'name'        => 'required|string|max:255',
            'positions'   => 'required|string|max:255',
            'room'        => 'required|string|max:255',
            'facility'    => 'required|string|max:255',
            'category'    => 'required|string|in:IT,IPSRS',
            'description' => 'required|string',
            'status'      => 'required|string',
            'note'        => 'nullable|string',
            'image'       => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ];

        // 🔸 Jika status = "Selesai diproses", maka process_image wajib diisi
       // 🔸 Jika status = "Selesai diproses", maka process_image wajib diisi hanya jika belum ada foto lama
        if ($request->status === 'Selesai diproses') {
            if (!$report->process_image) {
                $rules['process_image'] = 'required|image|mimes:jpg,jpeg,png|max:2048';
            } else {
                $rules['process_image'] = 'nullable|image|mimes:jpg,jpeg,png|max:2048';
            }
        } else {
            $rules['process_image'] = 'nullable|image|mimes:jpg,jpeg,png|max:2048';
        }


        $request->validate($rules, $messages, $attributes);

        $data = $request->only(['name', 'positions', 'room', 'facility', 'category', 'description', 'status']);
        $data['note'] = $request->note ?? '-';
        $data['updated_by'] = auth()->id();

        // 🔹 Otomatis catat waktu proses dan selesai berdasarkan perubahan status
        if ($request->status === 'Sedang diproses') {
            if (!$report->processed_at) {
                $data['processed_at'] = now();
            }
        } elseif ($request->status === 'Selesai diproses') {
            if (!$report->processed_at) {
                $data['processed_at'] = now();
            }
            if (!$report->completed_at) {
                $data['completed_at'] = now();
            }
        }

        // 🔹 Upload foto selesai
        if ($request->hasFile('process_image')) {
            if ($report->process_image && Storage::disk('public')->exists($report->process_image)) {
                Storage::disk('public')->delete($report->process_image);
            }
            $data['process_image'] = $request->file('process_image')->store('reports/process', 'public');
        }

        // 🔹 Upload foto awal (jika diubah)
        if ($request->hasFile('image')) {
            if ($report->image && Storage::disk('public')->exists($report->image)) {
                Storage::disk('public')->delete($report->image);
            }
            $data['image'] = $request->file('image')->store('reports', 'public');
        }

        $report->update($data);

        // Simpan riwayat perubahan baru (update status, catatan, foto proses)
        $report->histories()->create([
            'user_id' => auth()->id(),
            'status'  => $request->status,
            'note'    => $request->note ?? '-',
            'image'   => isset($data['process_image']) ? $data['process_image'] : null,
        ]);

        return redirect()->route('reports.index')
            ->with('success', 'Report updated successfully.');
    }

    public function destroy(Report $report)
    {
        $report->delete();
        return redirect()->route('reports.index')
            ->with('success', 'Report deleted successfully.');
    }

    public function report(Request $request)
    {
        $startDate = $request->input('start_date');
        $endDate   = $request->input('end_date');
        $status    = $request->input('status');

        $query = Report::query();

        if ($startDate && $endDate) {
            $query->whereBetween('created_at', [
                Carbon::parse($startDate)->startOfDay(),
                Carbon::parse($endDate)->endOfDay(),
            ]);
        }

        if ($status) {
            $query->where('status', $status);
        }

        $reports = $query->orderBy('id', 'desc')->get();
        $totalReports = $reports->count();

        return Inertia::render('Reports/ReportIndex', [
            'reports'      => $reports,
            'totalReports' => $totalReports,
            'filters'      => [
                'start_date' => $startDate,
                'end_date'   => $endDate,
                'status'     => $status,
            ],
        ]);
    }

    public function exportPdf(Request $request)
    {
    $startDate = $request->input('start_date');
    $endDate   = $request->input('end_date');
    $status    = $request->input('status');

    $query = Report::query();

    if ($startDate && $endDate) {
        $query->whereBetween('created_at', [
            Carbon::parse($startDate)->startOfDay(),
            Carbon::parse($endDate)->endOfDay(),
        ]);
    }

    if ($status) {
        $query->where('status', $status);
    }

    $reports = $query->orderBy('id', 'desc')->get();

    $totals = [
        'diajukan'  => $reports->where('status', 'Sedang diajukan')->count(),
        'diproses'  => $reports->where('status', 'Sedang diproses')->count(),
        'selesai'   => $reports->where('status', 'Selesai diproses')->count(),
        'total'     => $reports->count(),
    ];

    $pdf = Pdf::loadView('pdf.reports', [
        'reports' => $reports,
        'totals'  => $totals,
        'startDate' => $startDate,
        'endDate' => $endDate,
        'status' => $status,
    ])->setPaper('a4', 'landscape');

    return $pdf->download('laporan-kerusakan.pdf');
    }

    public function exportExcel(Request $request)
    {
        $startDate = $request->input('start_date');
        $endDate   = $request->input('end_date');
        $status    = $request->input('status');

        $query = Report::query();

        if ($startDate && $endDate) {
            $query->whereBetween('created_at', [
                Carbon::parse($startDate)->startOfDay(),
                Carbon::parse($endDate)->endOfDay(),
            ]);
        }

        if ($status) {
            $query->where('status', $status);
        }

        $reports = $query->orderBy('id', 'desc')->get();

        $totals = [
            'diajukan'  => $reports->where('status', 'Sedang diajukan')->count(),
            'diproses'  => $reports->where('status', 'Sedang diproses')->count(),
            'selesai'   => $reports->where('status', 'Selesai diproses')->count(),
            'total'     => $reports->count(),
        ];

        $filename = 'laporan-kerusakan-' . date('Ymd-His') . '.xls';

        // Menambahkan UTF-8 BOM agar Excel mengenali karakter khusus (Unicode/UTF-8) dengan benar
        $content = "\xEF\xBB\xBF" . view('excel.reports', [
            'reports'   => $reports,
            'totals'    => $totals,
            'startDate' => $startDate,
            'endDate'   => $endDate,
            'status'    => $status,
        ])->render();

        return response($content)
            ->header('Content-Type', 'application/vnd.ms-excel; charset=utf-8')
            ->header('Content-Disposition', "attachment; filename=\"$filename\"")
            ->header('Pragma', 'no-cache')
            ->header('Expires', '0');
    }
}
